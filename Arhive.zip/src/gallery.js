import React, { Component } from 'react';
import './gallery.css';
import Img1 from '../gallery/oneDa.png';
import Img2 from '../gallery/oneDan.png';
import Img3 from '../gallery/oneDs.png';

const IMG=[{
    "count":"0",
    "alt":"Встраиваемая кухня",
    "src":Img1,
    "hash": "kitchen",
    "title": "заказать кухню"
    },{
    "count":'1',
    "alt":"Модульная кухня",
    "src":Img2,
    "hash": "kitchenNew",
    "title": "Кухня на заказ"
    },{
    "count":'2',
    "alt":"Кхня на заказ",
    "src":Img3,
    "hash": "kitchenTwo",
    "title": "Good things Are going to Happen"
  }];

class Gallery extends Component {
  render() {
    return (
      <React.Fragment>
      <h1 style={{width:"100%",textAlign:"center"}}>Gallery JS</h1>
      <img src={IMG[0].src} alt={IMG[0].alt} title={IMG[0].title}/>
      <img src={IMG[1].src} alt={IMG[1].alt} title={IMG[1].title}/>
      <img src={IMG[2].src} alt={IMG[2].alt} title={IMG[2].title}/>
      </React.Fragment>
    );
  }
}

export default Gallery;
