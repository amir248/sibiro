import React, { Component } from 'react';

class LearnMore extends Component {
  render() {
    return (
      <React.Fragment>
      <h2>cards Learn more</h2>
      </React.Fragment>
    );
  }
}

export default LearnMore;
