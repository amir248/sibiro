import React, { Component } from 'react';

import './firstGallery.css';
import Vidos from '../video/v1.mp4';
import Vidos2 from '../video/v2.mp4';


const Vid=()=>{
  if(document.querySelector('#viv > video:nth-child(2)')){
    console.log("true");
}else{
   const videous=document.createElement('video');
   document.querySelector('#viv').append(videous);
   videous.setAttribute('src',Vidos);
   videous.setAttribute('controls', '');
   let one=document.createElement('p');
   document.querySelector('#viv').append(one);
   one.style.cssText=`width:300px;border-radius:20px;background:green;height:37px;text-align:center;`
   one.innerHTML='Первое видео';
   one.setAttribute('id', 'twoVidos');
   let two=document.createElement('p');
   videous.setAttribute('src',Vidos);

   document.querySelector('#viv').append(two);
   two.innerHTML='two video';
   two.setAttribute('id', 'twoVidos2');
   two.style.cssText=`width:300px;border-radius:20px;background:coral;height:37px;text-align:center;`

     document.querySelector('#twoVidos').addEventListener("click",()=>{
        videous.setAttribute('src',Vidos);
     });
     document.querySelector('#twoVidos2').addEventListener('click',()=>{
       videous.setAttribute('src',Vidos2);
     });

   }
}

class Video extends Component {
  render() {
    return (
      <React.Fragment>
      <div id="viv" style={{display:'flex',justifyContent:"center",alignItems:"center",flexDirection:"column"}}>
      <h2 style={{textAlign:"center",margin:"1%"}} onClick={Vid}>Video<span style={{color:"green", fontSize:"15px",borderRadius:"10px",background:"rgba(255,0,0,0.3)",padding:"3%"}}>"onClick"</span></h2>
      </div>
      </React.Fragment>
    );
  }
}

export default Video;
