import React, { Component } from 'react';
import './gallery.css';
import Img1 from '../gallery/oneDa.png';
import Img2 from '../gallery/oneDan.png';
import Img3 from '../gallery/oneDs.png';
import Img4 from '../gallery/oneDsa.png';
import Img5 from '../gallery/oneDt.png';
import Img6 from '../gallery/oneKuh.png';
import Img7 from '../gallery/oneTwon.png';
import Img8 from '../gallery/oneUs.png';
import Img9 from '../gallery/oneUY.png';
import Img10 from '../gallery/oneUs.png';
import Img11 from '../gallery/oneYt.png';
import Img12 from '../gallery/oneSgib.png';

const IMG=[{
    "count":"0",
    "alt":"Встраиваемая кухня",
    "src":Img1,
    "hash": "kitchen",
    "title": "заказать кухню"
    },{
    "count":'1',
    "alt":"Модульная кухня",
    "src":Img2,
    "hash": "kitchenNew",
    "title": "Кухня на заказ"
    },{
    "count":'2',
    "alt":"Кхня на заказ",
    "src":Img3,
    "hash": "kitchenTwo",
    "title": "Good things Are going to Happen"
  },{
  "count":'3',
  "alt":"встраиваемая кухня",
  "src":Img4,
  "hash": "kitchenThree",
  "title": "Good things Are going to Happen"
  },{
  "count":'4',
  "alt":"встраиваемая кухня",
  "src":Img5,
  "hash": "kitchenThre",
  "title": "Good things Are going to Happen"
  },{
  "count":'5',
  "alt":"встраиваемая кухня",
  "src":Img6,
  "hash": "kitchenN",
  "title": "Good things Are going to Happen"
  },{
  "count":'6',
  "alt":"встраиваемая кухня",
  "src":Img7,
  "hash": "kitchen-",
  "title": "встраиваемая кухняn"
  },{
  "count":'7',
  "alt":"встраиваемая кухня",
  "src":Img8,
  "hash": "kitchenU",
  "title": "встраиваемая кухня"
  },{
  "count":'8',
  "alt":"встраиваемая кухня",
  "src":Img9,
  "hash": "kitchenh",
  "title": "Good things Are going to Happen"
  },{
  "count":'9',
  "alt":"встраиваемая кухня",
  "src":Img10,
  "hash": "kitchenhee",
  "title": "встраиваемая кухня"
  },{
  "count":'10',
  "alt":"встраиваемая кухня",
  "src":Img11,
  "hash": "kitchenhe",
  "title": "Good things Are going to Happen"
  },{
  "count":'11',
  "alt":"встраиваемая кухня",
  "src":Img12,
  "hash": "kitchenT",
  "title": "Good things Are going to Happen"
}];


const WIW=window.innerWidth<800;
const onLd=()=>{
  if(WIW){
    document.querySelector('body > main > gallery > img:nth-child(3)').style.cssText=`display:none;`
    document.querySelector('body > main > gallery > img:nth-child(4)').style.cssText=`display:none;`
  }
}
  let Cl=+0;
  const Clicker=()=>{
    console.log("FC Click"+Cl);
    Cl++;
    // body > main > gallery > img:nth-child(5)
    if(WIW){
      for(let Oj=0;Oj<IMG.length;Oj++){
      if(Cl===Oj){
          document.querySelector('body > main > gallery > img:nth-child(2)').setAttribute('src', IMG[Oj].src);
      }else{
          if(Cl===IMG.length){
            Cl=0;
          }
        }
      }
    }
  }
class Gallery extends Component {

  render() {
    return (
      <React.Fragment>


      <h1 style={{width:"100%",textAlign:"center"}} onLoad={onLd}>Gallery JS</h1>
      <img src={IMG[0].src} alt={IMG[0].alt} title={IMG[0].title} onLoad={onLd}  onClick={Clicker}/>
      <img src={IMG[1].src} alt={IMG[1].alt} title={IMG[1].title}/>
      <img src={IMG[2].src} alt={IMG[2].alt} title={IMG[2].title}/>
      </React.Fragment>
    );
  }
}

export default Gallery;
