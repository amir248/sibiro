import React, { Component } from 'react';

import './article.css';
//cart
import Cart from '../images/boxOne.png';



const windOne=()=>{
  if(window.innerWidth>1210){
    let append= document.querySelector('div.cart:nth-child(2) > img:nth-child(1)');
    document.querySelector('.cart').append(append);
  }
}

const windTwo=()=>{
  if(window.innerWidth>1210){
    let append2= document.querySelector('div.cart:nth-child(4) > img:nth-child(1)');
    document.querySelector('div.cart:nth-child(4)').append(append2);
  }
}

const windThre=()=>{
  if(window.innerWidth>1210){
    let append8= document.querySelector('div.cart:nth-child(6) > img:nth-child(1)');
    document.querySelector('div.cart:nth-child(6)').append(append8);
  }
}


class Article extends Component {
  constructor(props){
    super(props);
    this.state={
      count:0
    };
  }
  render() {
    return (
      <React.Fragment>
      <h2 id="first">Пять карт как в макете из фигмы</h2>
      <div className="cart">
        <img src={Cart} alt="catr" title="cart" onLoad={windOne}/>
        <div className="boxCart">
          <h3>Cart 1</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

        </div>
      </div>
      <div className="cart">
        <img src={Cart} alt="catr" title="cart" />
        <div className="boxCart">
        <h3>Cart 2</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      </div>
      </div>
      <div className="cart">
        <img src={Cart} alt="catr" title="cart" onLoad={windTwo}/>
        <div className="boxCart">
        <h3>Cart 3</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
      </div>
      <div className="cart">
        <img src={Cart} alt="catr" title="cart" />
        <div className="boxCart">
          <h3>Cart 4</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
      </div>
      <div className="cart">
        <img src={Cart} alt="catr" title="cart" onLoad={windThre}/>
        <div className="boxCart">
          <h3>Cart 5</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
      </div>
      </React.Fragment>
    );
  }
}

export default Article;
